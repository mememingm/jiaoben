const state = {
  jobId: null,
  rows: [],
  filteredRows: [],
  selectedIndex: null,
  selectedInventoryIds: new Set(),
  batch: null,
  pollTimer: null,
  loadingHistory: false,
};

const $ = (id) => document.getElementById(id);
const form = $("query-form");
const username = $("username");
const password = $("password");
const baseUrl = $("base-url");
const iccids = $("iccids");
const queryButton = $("query-button");
const cancelButton = $("cancel-button");
const loadHistoryButton = $("load-history");
const progressPanel = $("progress-panel");
const progressBar = $("progress-bar");
const progressMessage = $("progress-message");
const progressPercent = $("progress-percent");
const resultBody = $("result-body");
const search = $("search");
const statusFilter = $("status-filter");
const exportIccids = $("export-iccids");
const detailContent = $("detail-content");
const detailLabel = $("detail-label");
const historyAccount = $("history-account");
const batchTarget = $("batch-target");
const selectReleasedButton = $("select-released-button");
const clearSelectionButton = $("clear-selection-button");
const createBatchButton = $("create-batch-button");
const batchSelection = $("batch-selection");
const batchMessage = $("batch-message");
const batchResult = $("batch-result");

document.querySelectorAll('input[name="scope"]').forEach((radio) => {
  radio.addEventListener("change", () => {
    iccids.disabled = radio.value !== "selected";
    if (radio.value === "selected") iccids.focus();
  });
});
search.addEventListener("input", renderRows);
statusFilter.addEventListener("change", renderRows);
exportIccids.addEventListener("click", exportCurrentIccids);
form.addEventListener("submit", startQuery);
cancelButton.addEventListener("click", cancelQuery);
loadHistoryButton.addEventListener("click", loadLatestHistory);
batchTarget.addEventListener("input", updateBatchControls);
selectReleasedButton.addEventListener("click", selectReleasedRows);
clearSelectionButton.addEventListener("click", clearSelection);
createBatchButton.addEventListener("click", createWriteBatch);

function setFormMessage(message = "") {
  $("form-message").textContent = message;
}

function selectedScope() {
  return document.querySelector('input[name="scope"]:checked').value;
}

async function startQuery(event) {
  event.preventDefault();
  if (state.jobId || state.loadingHistory) return;
  setFormMessage("");
  const scope = selectedScope();
  const values = iccids.value.split(/[\s,;，；]+/).map((value) => value.trim()).filter(Boolean);
  if (scope === "selected" && values.length === 0) {
    setFormMessage("请输入至少一个 ICCID，或切换为全部 eSIM。 ");
    iccids.focus();
    return;
  }
  setBusy(true);
  state.rows = [];
  state.selectedIndex = null;
  state.selectedInventoryIds.clear();
  state.batch = null;
  renderBatchResult();
  setHistoryAccount("");
  renderRows();
  setProgress(0, "正在创建查询任务……");
  try {
    const response = await fetch("/api/jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: username.value.trim(),
        password: password.value,
        base_url: baseUrl.value.trim(),
        scope,
        iccids: values,
      }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "无法创建查询任务。");
    state.jobId = data.job_id;
    pollJob();
  } catch (error) {
    setBusy(false);
    setProgress(0, "查询未开始");
    setFormMessage(error.message);
  }
}

async function pollJob() {
  if (!state.jobId) return;
  try {
    const response = await fetch(`/api/jobs/${encodeURIComponent(state.jobId)}`, { cache: "no-store" });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "查询任务不存在。");
    setProgress(data.progress || 0, data.message || "正在处理……");
    $("status-message").textContent = data.message || "正在处理……";
    if (data.state === "done") {
      state.rows = Array.isArray(data.rows) ? data.rows : [];
      setHistoryAccount(data.account);
      $("output-paths").textContent = outputLabel(data.json_path, data.csv_path);
      finishQuery("查询完成，结果已保存。", false);
      return;
    }
    if (data.state === "failed") {
      finishQuery(data.error || "查询失败。", true);
      return;
    }
    if (data.state === "cancelled") {
      finishQuery("查询已取消。", true);
      return;
    }
    state.pollTimer = window.setTimeout(pollJob, 350);
  } catch (error) {
    finishQuery(error.message, true);
  }
}

async function cancelQuery() {
  if (!state.jobId) return;
  cancelButton.disabled = true;
  try {
    await fetch(`/api/jobs/${encodeURIComponent(state.jobId)}/cancel`, { method: "POST" });
  } catch (_error) {
    $("status-message").textContent = "正在停止查询……";
  }
}

async function loadLatestHistory() {
  if (state.jobId || state.loadingHistory) return;
  state.loadingHistory = true;
  loadHistoryButton.disabled = true;
  queryButton.disabled = true;
  setFormMessage("");
  setProgress(0, "正在读取上次保存的结果……");
  try {
    const response = await fetch("/api/history/latest", { cache: "no-store" });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "无法读取历史记录。");

    state.rows = Array.isArray(data.records) ? data.records : [];
    state.selectedIndex = null;
    state.selectedInventoryIds.clear();
    state.batch = null;
    setHistoryAccount(data.account);
    search.value = "";
    statusFilter.value = "all";
    detailLabel.textContent = "未选择记录";
    detailContent.textContent = "单击一条记录查看平台原始字段。";
    renderSummary();
    renderRows();
    renderBatchResult();
    const paths = outputLabel(data.json_path, data.csv_path);
    const historyName = data.history_filename ? `历史记录：${data.history_filename}` : "历史记录";
    $("output-paths").textContent = paths ? `${historyName} · ${paths}` : historyName;
    setProgress(100, "已加载上次结果");
    const queriedAt = formatHistoryTime(data.queried_at);
    const accountLabel = data.account || "未知账号（旧记录）";
    $("status-message").textContent = queriedAt
      ? `已加载上次结果（账号：${accountLabel}；查询时间：${queriedAt}）。`
      : `已加载上次结果（账号：${accountLabel}）。`;
  } catch (error) {
    setProgress(0, "历史记录未加载");
    setFormMessage(error.message === "还没有保存的历史记录。"
      ? "还没有保存的历史记录，请先查询一次。"
      : error.message);
    $("status-message").textContent = "历史记录未加载。";
  } finally {
    state.loadingHistory = false;
    loadHistoryButton.disabled = false;
    queryButton.disabled = Boolean(state.jobId);
    updateBatchControls();
  }
}

function finishQuery(message, isError) {
  if (state.pollTimer) window.clearTimeout(state.pollTimer);
  state.pollTimer = null;
  setBusy(false);
  $("status-message").textContent = message;
  if (isError) setFormMessage(message);
  if (!isError) renderSummary();
  renderRows();
}

function setBusy(busy) {
  state.jobId = busy ? state.jobId : null;
  queryButton.disabled = busy || state.loadingHistory;
  cancelButton.disabled = !busy;
  loadHistoryButton.disabled = busy;
  username.disabled = busy;
  password.disabled = busy;
  baseUrl.disabled = busy;
  document.querySelectorAll('input[name="scope"]').forEach((radio) => { radio.disabled = busy; });
  iccids.disabled = busy || selectedScope() !== "selected";
  updateBatchControls();
}

function setProgress(percent, message) {
  const value = Math.max(0, Math.min(100, Number(percent) || 0));
  progressPanel.hidden = false;
  progressBar.style.width = `${value}%`;
  progressPercent.textContent = `${Math.round(value)}%`;
  progressMessage.textContent = message;
}

function renderSummary() {
  $("metric-total").textContent = state.rows.length;
  $("metric-installed").textContent = state.rows.filter((row) => row.esimProfileStatus === "INSTALLED").length;
  $("metric-released").textContent = state.rows.filter((row) => row.esimProfileStatus === "RELEASED").length;
  $("metric-failed").textContent = state.rows.filter((row) => row.esimProfileStatusQueryStatus === "failed").length;
  updateBatchControls();
}

function renderRows() {
  const needle = search.value.trim().toLowerCase();
  const selected = statusFilter.value;
  state.filteredRows = state.rows.filter((row) => {
    const matchesSearch = !needle || JSON.stringify(row).toLowerCase().includes(needle);
    const matchesFilter = selected === "all"
      || (selected === "failed" && row.esimProfileStatusQueryStatus === "failed")
      || row.esimProfileStatus === selected;
    return matchesSearch && matchesFilter;
  });
  resultBody.replaceChildren();
  if (state.filteredRows.length === 0) {
    const tr = document.createElement("tr");
    tr.className = "empty-row";
    const td = document.createElement("td");
    td.colSpan = 6;
    td.innerHTML = '<div class="empty-state"><span class="empty-glyph">◌</span><strong>没有匹配记录</strong><span>调整筛选条件后再查看。</span></div>';
    tr.append(td);
    resultBody.append(tr);
  } else {
    state.filteredRows.forEach((row, index) => resultBody.append(createRow(row, index)));
  }
  $("record-count").textContent = `${state.filteredRows.length} / ${state.rows.length} 条`;
  exportIccids.disabled = state.filteredRows.length === 0;
  updateBatchControls();
}

function exportCurrentIccids() {
  const values = [...new Set(state.filteredRows.map((row) => String(row.iccid || "").trim()))]
    .filter((value) => /^[0-9]{18,22}$/.test(value));
  if (values.length === 0) {
    setFormMessage("当前列表没有可导出的 ICCID。 ");
    return;
  }
  const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
  const blob = new Blob([`${values.join("\n")}\n`], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `esim-iccids-${stamp}.txt`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  $("status-message").textContent = `已导出当前列表 ${values.length} 个 ICCID。`;
}

function createRow(row, index) {
  const tr = document.createElement("tr");
  if (state.selectedIndex === index) tr.classList.add("selected");
  const raw = row.esimProfileStatus;
  const failed = row.esimProfileStatusQueryStatus === "failed";
  const statusCell = failed ? chip("查询失败", "failed") : chip(profileLabel(raw), profileClass(raw));
  const selectionTd = document.createElement("td");
  selectionTd.className = "selection-cell";
  const selectable = isReleasedRow(row);
  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.className = "row-selector";
  checkbox.checked = selectable && state.selectedInventoryIds.has(row.id);
  checkbox.disabled = !selectable;
  checkbox.setAttribute("aria-label", `选择 ${row.iccid || "此卡"} 加入写卡批次`);
  checkbox.addEventListener("click", (event) => event.stopPropagation());
  checkbox.addEventListener("change", () => {
    if (checkbox.checked) state.selectedInventoryIds.add(row.id);
    else state.selectedInventoryIds.delete(row.id);
    updateBatchControls();
  });
  selectionTd.append(checkbox);
  tr.append(selectionTd);
  const values = [row.iccid || "", row.status || "", null,
    row.esimProfileStatusUpdatedAt || "", failed ? "失败" : (row.esimProfileStatusQueryStatus === "ok" ? "成功" : "")];
  values.forEach((value, cellIndex) => {
    const td = document.createElement("td");
    if (cellIndex === 2) td.append(statusCell);
    else {
      td.textContent = value;
      if (cellIndex === 4) td.className = failed ? "query-failed" : "query-ok";
    }
    tr.append(td);
  });
  tr.addEventListener("click", () => {
    state.selectedIndex = index;
    detailLabel.textContent = row.iccid || "未命名记录";
    detailContent.textContent = JSON.stringify(row, null, 2);
    renderRows();
  });
  return tr;
}

function isReleasedRow(row) {
  return row && row.esimProfileStatus === "RELEASED"
    && row.esimProfileStatusQueryStatus === "ok"
    && Number.isInteger(row.id) && row.id > 0;
}

function releasedRows() {
  return state.rows.filter(isReleasedRow);
}

function updateBatchControls() {
  const parsed = Number.parseInt(batchTarget.value, 10);
  const target = Math.max(1, Math.min(200, Number.isFinite(parsed) ? parsed : 200));
  if (document.activeElement !== batchTarget) batchTarget.value = String(target);
  const availableRows = releasedRows();
  const availableIds = new Set(availableRows.map((row) => row.id));
  const selected = [...state.selectedInventoryIds].filter((id) => availableIds.has(id)).length;
  batchSelection.textContent = `已选择 ${selected} 张；可用 RELEASED ${availableRows.length} 张；目标数量仅用于自动选择，批次上限 200 张。`;
  const locked = Boolean(state.jobId) || state.loadingHistory;
  batchTarget.disabled = locked;
  selectReleasedButton.disabled = locked || availableRows.length === 0;
  clearSelectionButton.disabled = locked || selected === 0;
  createBatchButton.disabled = locked || selected === 0;
}

function selectReleasedRows() {
  const parsed = Number.parseInt(batchTarget.value, 10);
  const target = Math.max(1, Math.min(200, Number.isFinite(parsed) ? parsed : 200));
  batchTarget.value = String(target);
  const candidates = releasedRows().slice(0, target);
  state.selectedInventoryIds = new Set(candidates.map((row) => row.id));
  renderRows();
  $("status-message").textContent = `已自动选择 ${candidates.length} 张 RELEASED 卡。`;
}

function clearSelection() {
  state.selectedInventoryIds.clear();
  renderRows();
  $("status-message").textContent = "已清除写卡批次选择。";
}

async function createWriteBatch() {
  const selectedRows = state.rows.filter((row) => state.selectedInventoryIds.has(row.id));
  if (selectedRows.length === 0) {
    batchMessage.textContent = "请先选择 RELEASED 卡。";
    return;
  }
  if (selectedRows.length > 200) {
    batchMessage.textContent = "单个批次最多 200 张卡。";
    return;
  }
  batchMessage.textContent = "正在保存写卡准备清单……";
  createBatchButton.disabled = true;
  try {
    const response = await fetch("/api/write-batches", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ count: selectedRows.length, rows: selectedRows }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "写卡批次创建失败。");
    state.batch = data;
    renderBatchResult();
    batchMessage.textContent = `批次已创建：${data.batch_id}。当前未获取二维码、未读取 LPA、未写卡。`;
    $("status-message").textContent = "写卡准备批次已保存。";
  } catch (error) {
    batchMessage.textContent = error.message;
  } finally {
    updateBatchControls();
  }
}

function renderBatchResult() {
  batchResult.replaceChildren();
  if (!state.batch) {
    batchResult.hidden = true;
    return;
  }
  batchResult.hidden = false;
  const title = document.createElement("strong");
  title.textContent = `${state.batch.batch_id} · ${state.batch.count} 张`;
  const note = document.createElement("span");
  note.textContent = "阶段：等待接入二维码/LPA";
  const link = document.createElement("a");
  link.href = state.batch.csv_download || "#";
  link.textContent = "下载 CSV 清单";
  link.download = "";
  batchResult.append(title, note, link);
}

function chip(label, kind) {
  const span = document.createElement("span");
  span.className = `status-chip status-${kind}`;
  span.textContent = label;
  return span;
}

function profileLabel(raw) {
  if (raw === "INSTALLED") return "已安装（INSTALLED）";
  if (raw === "RELEASED") return "已释放待下载（RELEASED）";
  return raw ? `原始值：${raw}` : "未返回状态";
}

function profileClass(raw) {
  if (raw === "INSTALLED") return "installed";
  if (raw === "RELEASED") return "released";
  return "raw";
}

function outputLabel(jsonPath, csvPath) {
  const name = (value) => value ? value.split(/[\\/]/).pop() : "";
  const values = [name(jsonPath), name(csvPath)].filter(Boolean);
  return values.length ? `已导出：${values.join("、")}` : "";
}

function setHistoryAccount(account) {
  const value = String(account || "").trim();
  historyAccount.textContent = value ? `账号：${value}` : "";
  historyAccount.hidden = !value;
}

function formatHistoryTime(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return new Intl.DateTimeFormat("zh-CN", {
    dateStyle: "medium",
    timeStyle: "medium",
  }).format(date);
}

renderSummary();
renderRows();
